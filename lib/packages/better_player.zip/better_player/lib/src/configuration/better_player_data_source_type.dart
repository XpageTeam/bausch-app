///Source types of video. Network type is used for videos that are hosted on
///the web service. File type is used for videos that will be read from
/// mobile device.
enum BetterPlayerDataSourceType { network, file, memory }
