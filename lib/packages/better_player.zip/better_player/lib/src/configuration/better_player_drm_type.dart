///Types of available DRM's
///token -> supported for both iOS/Android
///widevine -> supported only for Android
///fairplay -> suppoted only for iOS
///clearKey -> supported only for Android
enum BetterPlayerDrmType { token, widevine, fairplay, clearKey }
