///Representation of possible video formats in Better Player.
enum BetterPlayerVideoFormat {
  dash,
  hls,
  ss,
  other,
}
