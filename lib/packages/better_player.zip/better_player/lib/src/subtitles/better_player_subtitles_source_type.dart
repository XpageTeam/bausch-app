///Representation of possible source types of subtitles.
enum BetterPlayerSubtitlesSourceType { file, network, memory, none }
