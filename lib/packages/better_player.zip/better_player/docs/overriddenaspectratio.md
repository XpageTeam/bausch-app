## Overriden aspect ratio

You can override `BetterPlayerConfiguration`'s `aspectRatio` parameter in runtime with `setOverridenAspectRatio` method from `betterPlayerController`.
```dart
betterPlayerController.setOverriddenAspectRatio(1.0);
```