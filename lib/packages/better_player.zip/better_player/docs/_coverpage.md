![logo](https://raw.githubusercontent.com/jhomlala/betterplayer/master/media/logo.png)

# Better Player 
> Advanced video player for Flutter.

[![pub package](https://img.shields.io/pub/v/better_player.svg)](https://pub.dartlang.org/packages/better_player)
[![pub package](https://img.shields.io/github/license/jhomlala/betterplayer.svg?style=flat)](https://github.com/jhomlala/betterplayer)
[![pub package](https://img.shields.io/badge/platform-flutter-blue.svg)](https://github.com/jhomlala/betterplayer)

- Highly customizable
- Solves many typical use cases and it's easy to run
- Supports both Android and iOS

[GitHub](https://github.com/jhomlala/betterplayer)
[Get Started](https://jhomlala.github.io/betterplayer/#/README)