### Mix audio with others
You can enable mix with audio with others app with method:
```dart
betterPlayerController.setMixWithOthers(true)
```
Default value is false.